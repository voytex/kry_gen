# Zabarveni konzole (testovano POUZE na macOS)

C_RED       = '\u001b[31m'
C_GREEN     = '\u001b[32m'
C_BLUE      = '\u001b[34m'
C_YELLOW    = '\u001b[33m'
C_RES       = '\u001b[0m'
