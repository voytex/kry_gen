<?php
define("DB_HOST", "innodb.endora.cz");
define("DB_USERNAME", "mpckrygr14");
define("DB_PASSWORD", "MPCkryGR14");
define("DB_DATABASE_NAME", "mpckrygr14");